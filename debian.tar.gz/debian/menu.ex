?package(limereg):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="limereg" command="/usr/bin/limereg"
