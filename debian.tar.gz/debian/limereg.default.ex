# Defaults for limereg initscript
# sourced by /etc/init.d/limereg
# installed at /etc/default/limereg by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
