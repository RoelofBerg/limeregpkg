#
# Regular cron jobs for the limereg package
#
0 4	* * *	root	[ -x /usr/bin/limereg_maintenance ] && /usr/bin/limereg_maintenance
